using Microsoft.AspNetCore.Mvc;

namespace NiceAdmin2.Controllers;

public class Order : Controller
{
    // GET
    public IActionResult Index()
    {
        return View("Order");
    }

    public IActionResult AddEditOrder()
    {
        return View();
    }

    public IActionResult Save()
    {
        return View("Order");
    }
}