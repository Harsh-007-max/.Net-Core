using CrudOpration.Models;
using Microsoft.AspNetCore.Mvc;

namespace NiceAdmin2.Controllers;

public class ProductController : Controller
{
    public List<ProductModel> ProductList = new List<ProductModel>
    {
        new ProductModel{ProductID=1,ProductName = "A",ProductPrice = 150,ProductCode ="123",Description = "ABC",UserID = 1},
        new ProductModel{ProductID=2,ProductName = "B",ProductPrice = 120,ProductCode ="23",Description = "ABC",UserID = 2},
        new ProductModel{ProductID=2,ProductName = "c",ProductPrice = 120,ProductCode ="23",Description = "ABC",UserID = 3},
    };
    // GET
    public IActionResult Index()
    {
        return View("Product",ProductList);
    }

    public IActionResult AddEditProduct()
    {
        return View();
    }
}