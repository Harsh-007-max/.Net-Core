using CrudOpration.Models;
using Microsoft.AspNetCore.Mvc;

namespace NiceAdmin2.Controllers;
using NiceAdmin2.Models;

public class User : Controller
{
    public List<UserModel> userList = new List<UserModel>
    {
        new UserModel{UserID=1,UserName = "A",Email = "ABC@gmail.com",Password = "pswd",MobileNo = "1234567890",Address = "Shaitan gali", IsActive = true},
        new UserModel{UserID=1,UserName = "A",Email = "ABC@gmail.com",Password = "pswd",MobileNo = "1234567890",Address = "Shaitan gali", IsActive = true},
    };
    // GET
    public IActionResult Index()
    {
        return View("User",userList);
    }

    public IActionResult AddEditUser()
    {
        return View();
    }
}