using Microsoft.AspNetCore.Mvc;

namespace NiceAdmin2.Controllers;

public class Bills : Controller
{
    // GET
    public IActionResult Index()
    {
        return View();
    }

    public IActionResult AddEditBills()
    {
        return View();
    }

    public IActionResult Save()
    {
        return View("Index");
    }
}