using CrudOpration.Models;
using Microsoft.AspNetCore.Mvc;
namespace NiceAdmin2.Controllers;
using NiceAdmin2.Models;

public class OrderDetails : Controller
{
    public List<OrderDetailModel> OrderDetailsList = new List<OrderDetailModel>
    {
        new OrderDetailModel{ OrderDetailID = 1,OrderID=1,ProductID=1,Quantity=1,Amount=1,TotalAmount=1,UserID=1 },
        new OrderDetailModel{ OrderDetailID = 2,OrderID=2,ProductID=2,Quantity=2,Amount=2,TotalAmount=2,UserID=2 },
        new OrderDetailModel{ OrderDetailID = 3,OrderID=3,ProductID=3,Quantity=3,Amount=3,TotalAmount=3,UserID=3 },
        new OrderDetailModel{ OrderDetailID = 4,OrderID=4,ProductID=4,Quantity=4,Amount=4,TotalAmount=4,UserID=4 },
        new OrderDetailModel{ OrderDetailID = 5,OrderID=5,ProductID=5,Quantity=5,Amount=5,TotalAmount=5,UserID=5 },
    };
    // GET
    public IActionResult Index()
    {
        return View(OrderDetailsList);
    }

    public IActionResult AddEditOrderDetails()
    {
        return View();
    }
}