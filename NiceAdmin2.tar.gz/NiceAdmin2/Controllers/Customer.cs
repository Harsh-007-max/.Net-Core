using Microsoft.AspNetCore.Mvc;

namespace NiceAdmin2.Controllers;

public class Customer : Controller
{
    // GET
    public IActionResult Index()
    {
        return View();
    }

    public IActionResult AddEditCustomer()
    {
        return View();
    }

    public IActionResult Save()
    {
        return View("Index");
    }
}